clear
clc
h = 0.2;
x = 0:h:2;
n = length(x);
for i=1:(n-1)%derivatuive of function
    dy(i) = -sin(x(i)) * exp(x(i)^2) + cos(x(i)) * exp(x(i)^2) * 2 * x(i)
end
for i=2:(n-1)%derivatuive of function by using numerical method
    dy1(i)=(cos(x(i)) * exp(x(i)^2) - cos(x(i - 1)) * exp((x(i-1))^2)) / h;
    er1(i)=abs(dy(i)-dy1(i));
end
dy
dy1
plot(2:(n-1), dy(2:(n -1)))
hold on
plot(2:(n-1), dy1(2:(n-1)))
hold on
for i=1:(n-1)%second derivatuive of function
    ddy(i) = -cos(x(i)) * exp(x(i) ^ 2) - sin(x(i)) * 2*x(i) * exp(x(i) ^ 2) - sin(x(i)) * exp(x(i)^2) * 2 * x(i) + cos(x(i)) * exp(x(i) ^ 2) * 4 * x(i) ^ 2 + cos(x(i)) * exp(x(i) ^ 2) * 2
end
for i=2:(n-2)%second derivatuive of function by using numerical method
    ddy1(i) = cos(x(i + 1)) * exp(x(i + 1)^2) - 2 * cos(x(i)) * exp(x(i)^2) + cos(x(i-1)) * exp(x(i-1)^2)
end
plot(2:ddy(n-2), 'color', 'red')
hold on
plot(2:ddy1(n-2), 'color', 'red')
% x = [3.37, 8.08, 11.76, 12.15, 13.25, 14.53]
% y = [1.4272, 17.6441, 63.6593, 71.6087, 98.4015, 139.1986]


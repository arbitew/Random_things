function [y] = Lab_11_fun(d)
y = pi * d * (4 * 1500/(pi * d^2)) + (pi * (d^2) * 0.4)/4 + pi * (d^2) * 0.6/4


end


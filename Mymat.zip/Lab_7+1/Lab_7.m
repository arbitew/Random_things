clear
clc
x = [3.37; 8.08; 11.76; 12.15; 13.25; 14.53]
y = [1.4272; 17.6441; 63.6593; 71.6087; 98.4015; 139.1986]
W = vander(x)%Vandermond matrix
a = inv(W) * y;%interpolation by Vandermond matrix
x = [3.37, 8.08, 11.76, 12.15, 13.25, 14.53]
y = [1.4272, 17.6441, 63.6593, 71.6087, 98.4015, 139.1986]
p = polyfit(x, y, 5);%interopolation polinomial 5th power
p = polyfit(x, y, 2);%interopolation polinomial 2nd power
ezplot('1.5243*x^2 - 15.4574 * x + 37.6454', [3, 15])%interopolation polinomial 2nd power
hold on
grid on
for i = 1:length(x)
    plot(x(i), y(i), 'r.', 'MarkerSize', 20)
end
a'
p

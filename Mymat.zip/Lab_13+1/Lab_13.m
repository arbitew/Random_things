clear
clc
f1 = @(x, y1, y2) power(y1, exp(x*x)) + x * y2
f2 = @(x, y1, y2) 3 * x - y1 + 2*y2
ode45(@Lab_13_f, [0.1  1], [0, 1])
% [x, y] = ode45(@Lab_13_f, [1  10], [0.1 0.5])
% plot(x, y, '-k')
h = 0.1
x = 0:h:1
y1 = 0:h:1
y2 = 0:h:1
y1(1) = 1
y2(1) = 1
for i = 1:(length(x))
    y1(i) = f1(x(i), y1(i), y2(i))
    y2(i) = f2(x(i), y1(i), y2(i))
end
plot(x, y1)
hold on
plot(x, y2)

k1 = 0:h:1
k2 = 0:h:1
el1 = 0:h:1
el2 = 0:h:1
for i = 1:(length(x))
    k1 = h * f1(x(i), y1(i), y2(i))
    k2 = h * f2(x(i), y1(i), y2(i))
    
    y1(i) = f1(x(i), y1(i), y2(i))
    y2(i) = f2(x(i), y1(i), y2(i))
end

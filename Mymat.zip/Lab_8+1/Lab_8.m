clear
clc
x = [4.9 5.86 9.6 12.03 14.52 15.3]%coordinates of points
y = [7.2879 7.7919 23.105 59.2413 139.5528 177.8076]
n = 1
e = 100
for i = 1:(length(x) - 2)%Finding optimal degree of the polynomial
    y0 = polyval(polyfit(x, y, i), x);
    if(e > ((((1/5)* sum(y - y0).^2))^5))
        e = ((((1/5)* sum(y - y0).^2))^5)
        n = i
    end
end
% V = vander(x')
% V = V(1:length(V), 2:length(V))%polynomial by Vander
% A = V * V'
% b = V' * y'
% a = inv(A) * b
% aa = polyfit(x, y, n)
coef = polyfit(x, y, n)
plot(x, y, '*', 'color', 'red');% points at plot
hold on
grid on
%plotted polynomial approximant (blue) 
f = ezplot('0.0073 * x ^ 4  - 0.0992 * x ^ 3 + 0.7218 * x ^ 2  - 3.2044 * x + 13.1280', [4, 16])
set(f, 'color', 'red');
hold on
w = [0.8 0.8 0.9 0.4 1 0.7]%weighting coefficient
sp = spap2(1 , 4, x, y, w)%spap2 (red) approximating spline
fnplt(sp)

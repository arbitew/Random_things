clear
clc

A = [-0.76 -0.04 0.21 -0.18 ;
     0.45 -1.23 0.66 0.0 ;
     0.26 0.34 -1.11 0.0 ;
     0.05 -0.26 0.34 -1.12;]% diagonal elements are maximum by module
b = [-1.24;
    0.88;
    -0.63;
    1.17;]%f

linsolve(A, b)

A = [-0.76 -0.04 0.21 -0.18 ;
     0.45 -1.23 0.66 0.0 ;
     0.26 0.34 -1.11 0.0 ;
     0.05 -0.26 0.34 -1.12;]% diagonal elements are maximum by module
b = [-1.24;
    0.88;
    -0.63;
    1.17;]%f
E = 0.1;% accuracy
x = zeros(length(A), 1)% x

d = zeros(length(A), 1)% d

sob = zeros(length(A), 1)% new x

e = zeros(length(A), 1)

for i = 1:length(e)
    e(i) = 1
end

C = (length(A))

for i = 1:length(A)% C and getting their value
    d(i) = b(i) / A(i, i)
    for j = 1:length(A)
        if (j == i)
            C(j, i) = 0
        else
            C(j, i) = -A(j, i)/A(i, i)
        end
    end
end

flag = 1

while (flag ~= 0)
    for i = 1:length(A)
        
        for j = 1:length(A)% finding new x
            sob(i) = sob(i) +  C(j, i) * x(j);
        end
        sob(i) = sob(i) + d(i)
        
        if (flag == 2)% finding "e"
            for j = 1:length(A)
            e(i) = abs(sob(i) - x(i))
            end
        else%for first iteration
            if(i == 4)
                flag = 2;
            end
        end
        
        x(i) = sob(i); %x = new x
    end
    sob = zeros(length(sob), 1)% getting new values
    if(max(e) < E)% if an condition is performed
        flag = 0
    end
    
end

x


% A = [-0.76 -0.04 0.21 -0.18 ;
%      0.45 -1.23 0.66 0.0 ;
%      0.26 0.34 -1.11 0.0 ;
%      0.05 -0.26 0.34 -1.12;];% diagonal elements are maximum by module
% b = [-1.24;
%     0.88;
%     -0.63;
%     1.17;];%f
% 
% E = 0.1;% accuracy
% 
% x = zeros(length(A), 1)% x
% 
% sob = zeros(length(A), 1)% new x
% 
% [L1, U] = lu(A)
% D = diag(diag(A))
% flag = 1;
% 
% e = zeros(length(A), 1)
% 
% for i = 1:length(e)
%     e(i) = 1
% end
% 
% while (flag ~= 0)
%     for i = 1:length(sob)
%         sob(i) = sob(i) -((L1 + D)^(-1))*U*x(i) + ((L1 + D)^(-1)) * b(i) 
%     end
%     if(flag == 1)
%         flag = 2
%     else
%         for i = 1:length(e)
%             e(i) = abs(sob(i) - x(i))
%         end
%         x = sob
%     end
%     sob = zeros(length(sob), 1)% getting new values
%     if(max(sob(i) < E))
%         flag = 0
%     end
% end
%__________________________________Task_2__________________________________

A = [2 1 4 1;%eigenvector of matrix
    3 0 1 1;
    -1 2 3 4;
    3 1 1 1;]
eig(A)%eigen values of matrix
[V, G] = eig(A);%eigen vector of matrix
V

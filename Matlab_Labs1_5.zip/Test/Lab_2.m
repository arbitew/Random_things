a = [3 6 1 0; 
    0 0 0 2; 
    3 5 1 1; 
    0 1 0 1; 
    8 8 1 0; 
    8 7 1 1; 
    0 2 1 0; 
    0 1 1 1];
r = rank(a);
s = length(a(1,:));
s1 = length(a(1:8));
d = zeros(1, s * s1 + 1);
f = 0;
for i = 0:1:length(a(1,:)) - r
    for j = 0:1:length(a(1:end,1)) - r
        k = det(a(j + 1:r + j, i+1:r + i));
        if (abs(k) > 0.001)
            f = f + 1;
             d(f) = k;
        end
    end
end
d
f

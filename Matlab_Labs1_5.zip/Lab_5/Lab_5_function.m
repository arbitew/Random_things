function y = Lab_5_function(x);
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here 
    y = -2*x^2 + 3*x + 5;
end
    

clear
clc
ezplot('-2*x^2 + 3*x + 5', [-2;5])%reduce interval
hold on
grid on
x0 = 3
f = @(x) (-2*x^2 + 3*x + 5)
[a, b, c, d] = fzero(f, x0)
x = -2;
h = 0.1
E = 0.01
%--------------------------------------------------------------------------
while ((Lab_5_function(x) * Lab_5_function(x + h)) > 0);%enumerate technique
    x = x + h;
end
plot(x, 0, 'g.', 'MarkerSize', 20)
a = x
b = x + h

count = 0;%counter

while (abs(b - a) > E);%bisection method
    c = (a + b)/2;
    count = count + 1;
    if(Lab_5_function(a) * Lab_5_function(c) > 0)
        a = c;
    else
        b = c;
    end
end
x = c
count
plot(c, 0, 'r.', 'MarkerSize', 20)
hold on
x = 0
while ((Lab_5_function(x) * Lab_5_function(x + h)) > 0);%enumerate technique
    x = x + h;
end

a = x
b = x + h
while (abs(b - a) > E);%bisection method
    c = (a + b)/2;
    if(Lab_5_function(a) * Lab_5_function(c) > 0)
        a = c;
    else
        b = c;
    end
end
c
plot(c, 0, 'r.', 'MarkerSize', 20)
hold on


%-2*x^2 = -3*x - 5
%x = 1.5 + 2.5/x
%phi'(x) = -2.5/x^2

%-2*x^2 + 3*x + 5
%-4*x + 3
%-4

%--------------------------------------------------------------------------
x = -2
h = 0.1

count = 0;%counter
while ((Lab_5_function(x) * Lab_5_function(x + h)) > 0);%enumerate technique
    x = x + h;
end
if((Lab_5_function(x) * (-4)) < 0)
    x = x + h;
else
end
while (((abs(Lab_5_function(x) / (-4*x + 3)))> E))%Newton method
    count = count + 1;
    x = x - (Lab_5_function(x) / (-4*x + 3));
    abs(Lab_5_function(x) / (-4*x + 3));
end
x
count
plot(x, 0, 'b.', 'MarkerSize', 20)

x = 3
h = 0.1

while ((Lab_5_function(x) * Lab_5_function(x + h)) > 0);%enumerate technique
    x = x - h;
end
if((Lab_5_function(x) * (-4)) < 0)
    x = x - h;
else
end
while (((abs(Lab_5_function(x) / (-4*x + 3)))> E))%Newton method
    x = x - (Lab_5_function(x) / (-4*x + 3));
    abs(Lab_5_function(x) / (-4*x + 3));
end
x
plot(x, 0, 'b.', 'MarkerSize', 20)
x = -2;
h = 0.1;
%--------------------------------------------------------------------------

while ((Lab_5_function(x) * Lab_5_function(x + h)) > 0);%enumerate technique
    x = x + h;
end
a = x
b = x + h
if((Lab_5_function(x) * (-4)) > 0)
    x = a
    z = b
else
    x = b
    z = a
end
x1 = x + 1;
h = 1;
d = 0;

count = 0;%counter

while (((abs(x1 - x)) > E) && (abs(h) > E))%chord method
    count = count + 1;
    if (d == 0)
        d = 1;
    else
        x = x1;
    end
    h = (x - z) * Lab_5_function(x)/(Lab_5_function(x) - Lab_5_function(z));
    x1 = x - h;
end
x = x1
count
plot(x, 0, 'y.', 'MarkerSize', 20)



x = 0;
h = 0.1;

while ((Lab_5_function(x) * Lab_5_function(x + h)) > 0);%enumerate technique
    x = x + h;
end
a = x
b = x + h
if((Lab_5_function(x) * (-4)) > 0)
    x = a
    z = b
else
    x = b
    z = a
end
x1 = x + 1;
h = 1;
d = 0;
while (((abs(x1 - x)) > E) && (abs(h) > E))%chord method
    if (d == 0)
        d = 1;
    else
        x = x1;
    end
    h = (x - z) * Lab_5_function(x)/(Lab_5_function(x) - Lab_5_function(z));
    x1 = x - h;
end
x = x1
plot(x, 0, 'y.', 'MarkerSize', 20)
%-------    -------------------------------------------------------------------

syms j;%symbolic solution
eqn = -2*j^2 + 3*j + 5
s = solve(eqn, j, 'Real', true)

a = 1;
b = 2;
a = a + b;
%grid on
subplot(2, 2, 1)
ezplot('x^3 - x', [-4 4]);
subplot(2, 2, 2)
ezplot('1/x^2', [-2 2]);
subplot(2, 2, 3)
ezplot('tan(x/2)', [-pi pi]);
axis([-pi pi -10 10])
subplot(2, 2, 4)
ezplot('exp((-x ^ 2) / 2)', [-1.5 1.5]);
hold on;
ezplot('x^4 - x^2', [-1.5 1.5]);
title('exp((-x ^ 2) / 2) and x^4 - x^2')
%axis([-1.5 1.5 0.3 1])
%subplot(g1, g2, g3)

clear
clc
f = ezplot('y^5 = exp(-x) + x + 3', [0;2])
set(f, 'Color', 'red', 'LineWidth', 3)
hold on
grid on
f1 = ezplot('y = exp(x) - y^2', [0;2])
set(f1, 'Color', 'blue', 'LineWidth', 3)
syms x y;   
eqns = [-y^5 + exp(-x) + x + 3 == 0, -y + exp(x) - y^2 == 0]
% vars = [x, y] 
% s = solve(eqns, vars)


E = 0.001
e = [1, 1]
% e1 = [1, 1]
d = 0
y = 1
x = 1
while(max(e) > E)
    new_x = y^5 - exp(-x) - 3
    new_y =  exp(x) - 1
    if (d == 0)
        d = 1
    else
        e(1) = abs(new_x - x);
        e(2) = abs(new_y - y)
    end
    x = new_x
    y = new_y
end

A = [6 -1 -1;
    1 -2 3;
    3 4 4;];
b = [0;
    1;
    1;];
x = inv(A)*b
d = det(A)
r = rank(A)
n = norm(A)
u = norm(A) * norm(inv(A))
%good conditioned matrix
%Gauss method
A = [A, b]
N = eye(length(A) - 1)
for i = 1:length(A) - 1
    for j = i:length(A) - 1
        N(j, i) = -A(j, i) / A(i, i)
    end
    A = N*A
    N = eye(length(A) - 1)
end
% x = zeros(length(A) - 1, 1)
% x(length(A) - 1, 1) = A(lengh(A) - 1, lengh(A))/A(lengh(A) - 1, lengh(A) - 1)
% for i = 1:length(A) - 2
%     for j = lenght(A) - 1 - i:length(A)
%         
%     end
% end

%LU decomposition
A = [2.34 -1.42 -0.54 0.21;
1.44 -0.53 1.43 -1.27;
0.63 -1.32 -0.65 1.43;
0.56 0.88 -0.67 -2.38;]
b = [0.66;
    -1.44;
    0.94;
    0.73;]
 
[L1, U, P] = lu(A)
v = L1\b;
u = U\v

clear
clc

x = [0.298 0.303 0.310 0.317 0.323 0.330]
xx = linspace(0.298, 0.330, 100);
y = [2.25578 3.17639 3.12180 3.04819 2.98755 2.91950]
a = x;
b = y;
for k = 1:length(x)
    a(k) = 0;
end
x
y
for i = 1:(length(x) - 1)% table of finite differences
    for k = length(x) - i:length(x)
            a(k) = 0;
    end
    for j = 1:length(x) - i
        a(j) = b(j + 1) - b(j);
    end
    b = a;
    a
end
yy = spline(x, y, xx)%spline interpolation
plot(x, y)
grid on
hold on
plot(xx, yy, 'Color', 'red')
for i = 1:length(x)
    plot(x(i), y(i), 'r.', 'MarkerSize', 20)
end


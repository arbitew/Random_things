clear
clc
%analitycal calculating
%x*exp(-x) + log(x) + 1
%x_start = 0 x_end = 10 
%-x*exp(-x) - exp(-x) + x * log(x)
%ans = 11.09
% f = sym(cos(x) * exp(x ^ 2))
a = 0
b = 10
syms x
int(x*exp(-x) + log(x) + 1)%analitycal integral calculantint
ezplot('x*exp(-x) + log(x) + 1')
% dy = exp(-x) - x * exp(-x) + 1/x
% d2y = -2 * exp(-x) + x * exp(-x) - 1/(x^2)
h = 0.1
x1 = (1:h:11);
y = 1:h:11;
for i = 1:length(x1)
    x1(i) = i;
    y(i) = -2 * exp(-x1(i)) + x1(i) * exp(-x1(i)) - 1/(x1(i)^2);
end
max(y)
h = sqrt(12* (10^(-2))/((b - a) * max(y)))% integration step for trapeze method
y1 = 0
for i = 1:length(x1)
    y1 = y1 + (h/2) * ((x1(i)*exp(-x1(i)) + log(x1(i)) + 1) - ((x1(i)+h)*exp(-(x1(i)+h)) + log((x1(i)+h)) + 1));
end
y1
e = 10 ^ (-4)
h = sqrt(12* e/((b - a) * max(y)));% integration step for Simpson
f = @(x2)x2.*log(x2) - x2./exp(x2) - 1./exp(x2);
quad(f, 0, 10) %Simpson method using matlab functions
y1 = 0
for i = 1:length(x1)%Simpson method
    y1 = y1 + (h/6) * (((x1(i)*exp(-x1(i)) + log(x1(i)) + 1) + 4 * ((x1(i)+h/2)*exp(-(x1(i)+h/2)) + log((x1(i)+h/2)) + 1) + ((x1(i)+h)*exp(-(x1(i)+h)) + log((x1(i)+h)) + 1)));
end
y1
syms a
syms p
int(a^x * e ^ (-x))%calculating indefinite integral 

% double(int(x*exp(-x) + log(x) + 1), 0, Inf) - does not work
double(int('cos(x)+x^2',0,Inf))%infinity
double(int('1/(x^2+1)',0,Inf))
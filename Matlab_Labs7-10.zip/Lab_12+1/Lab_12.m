clear
clc
dsolve('Dy = (y/x) * (y/x) + (2 * (y/x))')
f = @(x, y) y / (2*x - y)
%Euler method
x = 1:0.1:1.5;
y = zeros(1, length(x));
y(1) = 0.5;
h = 0.1;
for i=1:(length(x)- 1)
    y(i + 1) = y(i) + h * f(x(i), y(i));
end
plot(x, y, 'color', 'black')
x1 = x
y1 = y
hold on
f1 = @(x, y) x*y
%ode45(f, [1, 1.5], [0, 1]) - Does not work 
[x, y] = ode45(f1, [1, 1.5], [0, 1]) % standart matlab method
ode45(f, [1, 1.5], [0.5])
hold on


f2 = @(x, y) 2 * y / power((2*x - y), 2)
f3 = @(x, y) 4 * y / power((2*x - y), 3)
f4 = @(x, y) 8 * y / power((2*x - y), 4)

%Runge-Kutta method
%h = 0.02
x = 1:0.02:1.5;
y = zeros(1, length(x));
y(1) = 0.5;
h = 0.02;
for i=1:(length(x)- 1)
    y(i + 1) = y(i) + h * f(x(i), y(i)) + (h * h / 2) * f2(x, y) + (h * h * h/ 6) * f3(x, y) + (h * h * h * h / 2) * f4(x, y);
end
plot(x, y, 'color', 'red')
hold on
x2 = x
y2 = y
%Runge-Kutta method
%h = 0.02
x = 1:0.005:1.5;
y = zeros(1, length(x));
y(1) = 0.5;
h = 0.005;
for i=1:(length(x)- 1)
    y(i + 1) = y(i) + h * f(x(i), y(i)) + (h * h / 2) * f2(x, y) + (h * h * h/ 6) * f3(x, y) + (h * h * h * h / 2) * f4(x, y);
end
x3 = x
y3 = y
plot(x, y, 'color', 'red')

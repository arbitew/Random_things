clear
clc
f1 = @(x, y1, y2) power(y1, exp(x*x)) + x * y2
f2 = @(x, y1, y2) 3 * x - y1 + 2*y2
subplot(2, 1, 1)   
ode45(@Lab_13_f, [0.1  1], [0, 1])% Standart matlab function
hold on
% [x, y] = ode45(@Lab_13_f, [1  10], [0.1 0.5])
% plot(x, y, '-k')
h = 0.1
x = 0:h:1
y1 = 0:h:1
y2 = 0:h:1
y1(1) = 1
y2(1) = 1
for i = 1:(length(x) - 1) % Euler method
    y1(i + 1) = y1(i) + h * f1(x(i), y1(i), y2(i));
    y2(i + 1) = y2(i) + h * f2(x(i), y1(i), y2(i));
end
plot(x, y1)
hold on
plot(x, y2)
hold on

% k1 = 0:h:1
% k2 = 0:h:1
% k3 = 0:h:1
% k4 = 0:h:1
% el1 = 0:h:1
% el2 = 0:h:1
% el3 = 0:h:1
% el4 = 0:h:1
for i = 1:(length(x) - 1) % Runge-Kutta method
    k1 = h * f1(x(i), y1(i), y2(i));
    el1 = h * f2(x(i), y1(i), y2(i));
    k2 = h * f1(x(i) + h/2, y1(i) +k1 / 2, y2(i) + el1 / 2);
    el2 = h * f2(x(i) + h/2, y1(i) + k1 / 2, y2(i) + el1 / 2);
    k3 = h * f1(x(i) + h/2, y1(i) +k2 / 2, y2(i) + el2 / 2);
    el3 = h * f2(x(i) + h/2, y1(i) +k2 / 2, y2(i) + el2 / 2);
    k4 = h * f1(x(i), y1(i) +k3, y2(i) + el3);
    el4 = h * f2(x(i), y1(i) +k3, y2(i) + el3);
    dy1 = (k1 + 2*k2 + 2*k3 + k4) / 6;
    dy2 = (el1 + 2*el2 + 2*el3 + el4) / 6;
    y1(i + 1) = y1(i) + dy1;
    y2(i + 1) = y2(i) + dy2;
end
% 
% plot(x, y1, 'color', 'red')
% hold on

f1 = @(x, y1, y2) power(y1, exp(-x*x)) + x * y2
f2 = @(x, y1, y2) 3 * x - y1 + 2*y2
plot(x, y2, 'color', 'red')
hold on
    
x
y1
y2

h = 0.1
x = 0:h:3
y1 = 0:h:3
y2 = 0:h:3
y1(1) = 1
y2(1) = 1
for i = 1:(length(x) - 1)% Euler method
    y1(i + 1) = y1(i) + h * f1(x(i), y1(i), y2(i));
    y2(i + 1) = y2(i) + h * f2(x(i), y1(i), y2(i));
end
subplot(2, 1, 2)   
plot(x, y1, 'color', 'yellow')
plot(x, y2, 'color', 'yellow')
hold on

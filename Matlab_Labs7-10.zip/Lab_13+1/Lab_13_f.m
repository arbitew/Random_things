function dy = Lab_13_f(x, y)
dy = zeros(2, 1)
dy(1) = power(y(1), exp(x*x))  + x * y(2)
dy(2) = 3 * x - y(1) + 2*y(2)   
% dy(1) = y(2)
% dy(2) = ((y(1)/x) - y(2))*(1/x) - y(1)
end


clear
clc
d = 4
pi * d * (4 * 1500/(pi * d^2)) + (pi * (d^2) * 0.4)/4 + pi * (d^2) * 0.6/4
ezplot('pi * d * (4 * 1500/(pi * d^2)) + (pi * (d^2) * 0.4)/4 + pi * (d^2) * 0.6/4', [1, 100])
f = @(x) pi * d * (4 * 1500/(pi * d^2)) + (pi * (d^2) * 0.4)/4 + pi * (d^2) * 0.6/4
[x,fval,exitflag,output] = fminbnd(f, 8, 20)
a = 8
b = 20
x1 = 0
x2 = 0
a1 = a
b1 = b
e = 0.01
z = 1.618
while((abs(a1 - b1)/2) > e) % golden section method
    x1 = a1 + z * (b1 - a1)
    x2 = b1 - z * (b1 - a1)
    if(f(x1) < f(x2))
        b1 = x2
    else
        a1 = x1
    end
end
x1
x2
% a1 = a
% b1 = b
% x1 = (a + b)/2
% x2 = x1 - (power(x1 - a, 2) * (f(x1) - f(b)) - power(x1 - b, 2) * (f(x1) - f(a)))/(2*((x1 - a) * (f(x1) - f(b)) - (x1 - b) * (f(x1) - f(a))))    
% while((abs(a1 - b1)/2) > e)
%     if((f(x1) < (f(x2))) && (x1 < x2))
%         b = x2
%     else if((f(x1) > (f(x2))) && (x1 < x2))
%         a = x1
%         end
%     end
%     if((f(x1) > (f(x2))) && (x1 > x2))
%         b = x1
%     else if((f(x1) < (f(x2))) && (x1 > x2))
%         a = x2
%         end
%     end
%     
%     x1 = (a + b + 2 * x2)/2
%     x2 = x1 - ((power(x1 - a, 2) * (f(x1) - f(b)) - power(x1 - b, 2) * (f(x1) - f(a)))/(2*((x1 - a) * (f(x1) - f(b)) - (x1 - b) * (f(x1) - f(a)))))
% end
% x1
% x2
